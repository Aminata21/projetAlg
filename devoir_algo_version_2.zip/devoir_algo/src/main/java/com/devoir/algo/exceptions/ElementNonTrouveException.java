package com.devoir.algo.exceptions;

public class ElementNonTrouveException extends Exception {
    public ElementNonTrouveException(){
        
    }
    public ElementNonTrouveException(String source, String errorMessage){
        super(source+" -> "+errorMessage);
    }
}
