package com.devoir.algo.modeles;

import java.util.ArrayList;
import java.util.List;

public class Chauffeur {
  // Declaration des variables
  private String nom;
  private String prenom;
  private int anneeEmbauche;
  private String adresse;
  private List<Trajet> trajetsEffectues;
  private List<Limousine> limousinesConduites;
  private String numeroDidentification;

  // Constructeur
  public Chauffeur(String nom, String prenom, int anneeEmbauche, String adresse) {
		super();
    this.nom = nom;
    this.prenom = prenom;
    this.anneeEmbauche = anneeEmbauche;
    this.adresse = adresse;
    this.numeroDidentification = this.nom.substring(0, 3) + this.prenom.charAt(0)
        + String.valueOf(this.anneeEmbauche).substring(2, 4);
    this.trajetsEffectues = new ArrayList<Trajet>();
    this.limousinesConduites = new ArrayList<Limousine>();
  }

  //
  public void setNom(String nOm) {
    this.nom = nOm;
  }

  public void setPrenom(String prenOm) {
    this.prenom = prenOm;
  }

  public void setAnneeEmbauche(int annee) {
    this.anneeEmbauche = annee;
  }

  public void setAdresse(String adr) {
    this.adresse = adr;

  }

  public String getNom() {
    return nom;
  }

  public String getPrenom() {
    return prenom;
  }

  public int getAnneeEmbauche() {
    return anneeEmbauche;
  }

  public String getAdresse() {
    return adresse;
  }

  public List<Trajet> getTrajetsEffectues() {

    return this.trajetsEffectues;
  }

  public void ajouterTrajet(Trajet trajet) {

    this.trajetsEffectues.add(trajet);

  }

  public String getNumeroDidentification() {
	  return numeroDidentification;
  }
  
  

  public boolean add(Limousine arg0) {
	return limousinesConduites.add(arg0);
}

public boolean contains(Object arg0) {
	return limousinesConduites.contains(arg0);
}

public List<Limousine> getLimousinesConduites() {
	return limousinesConduites;
}

public void setLimousinesConduites(List<Limousine> limousinesConduites) {
	this.limousinesConduites = limousinesConduites;
}

public void setTrajetsEffectues(List<Trajet> trajetsEffectues) {
	this.trajetsEffectues = trajetsEffectues;
}

public void setNumeroDidentification(String numeroDidentification) {
	this.numeroDidentification = numeroDidentification;
}

public String toString() {	  
    return "Numero Didentification : " + this.numeroDidentification + ", Nom : " + this.nom + " , prenom : " + this.prenom + " , annee d embauche : " + this.anneeEmbauche + " , Trajets Effectues : " + this.trajetsEffectues.toString();
  }
}