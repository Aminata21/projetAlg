package com.devoir.algo;

import com.devoir.algo.modeles.Compagny;
import com.devoir.algo.modeles.Compagny;
import com.devoir.algo.modeles.Reservation;
import java.util.List;
import java.util.Scanner;

import com.devoir.algo.modeles.Chauffeur;
import com.devoir.algo.modeles.Limousine;
import com.devoir.algo.modeles.Trajet;

public class App {

     static Compagny compagny;

     public static int afficherMenu(Scanner scan, int choix) {
        System.out.println("\n********** Menu **********");
            System.out.println("Entrez le chiffre correspondant pour acceder a la methode de votre choix");
            System.out.println("1.Creer un Chauffeur");
            System.out.println("2.Creer une limousine");
            System.out.println("3.Creer un trajet");
            System.out.println("4.Faire la reservation");
            System.out.println("5.Trouver les limousines conduites par un chauffeur donne");
            System.out.println("0.Quitter");

            System.out.println("Entrez votre choix: ");
            choix = scan.nextInt();
        return choix;
    }
    public static void enregistrerLimousine(Scanner scan, Compagny compagny){
        String numeroDimma, couleur;
        int capaciteReserv, nombreDePassagers;
        System.out.println("***************ENREGISTREMENT D UNE LIMOUSINE******************");
					System.out.println("entrez le numero dimmatriculation ");
					numeroDimma = scan.next();
					System.out.println("Entrez la capacite de reservation ");
					capaciteReserv = scan.nextInt();
					System.out.println("Entrez  le nombre de passagers");
					nombreDePassagers = scan.nextInt();
					System.out.println("entrez la couleur ");
					couleur = scan.next();

					final Limousine limousine = new Limousine(numeroDimma, capaciteReserv, nombreDePassagers, couleur);
					compagny.addLimousine(limousine);
					System.out.println(limousine.toString() + " enregistree avec succes...");
    }

    public static void enregistrerChauffeur(Scanner scan, Compagny compagny){
        String nom;
        String prenom, adresse;
        int anneeEmbauche;
        System.out.println("***************ENREGISTREMENT D UN CHAUFFEUR******************");
                    System.out.println("entrez le nom ");
                    nom = scan.next();
                    System.out.println("Entrez prenom ");
                    prenom = scan.next();
                    System.out.println("Entrez  l annee dEmbauche");
                    anneeEmbauche = scan.nextInt();
                    System.out.println("entrez l adresse ");
                    adresse = scan.next();
                    /*
                     * System.out.println ("entrez liste de trajet "); listeTrajets = scan.next();
                     * System.out.println ("entrez le numero Didentification ");
                     * numeroDidentification = scan.next();
                     */

                    final Chauffeur chauffeur = new Chauffeur(nom, prenom, anneeEmbauche, adresse);
                    compagny.addChauffeur(chauffeur);

                    System.out.println(chauffeur.toString() + " enregistre avec succes...");
    }

    public static void enregistrerTrajet(Scanner scan, Compagny compagny){
        String villeArrivee, villeDepart;
        int kmArrivee, kmDepart;
        System.out.println("***************ENREGISTREMENT D UN TRAJET******************");
					System.out.println("entrez la ville de depart ");
					villeDepart = scan.next();
					System.out.println("Entrez la ville darrivee ");
					villeArrivee = scan.next();
					System.out.println("Entrez  le nombre de passagers");
					kmArrivee = scan.nextInt();
					System.out.println("entrez la couleur ");
					kmDepart = scan.nextInt();

					final Trajet trajet = new Trajet(villeDepart, villeArrivee, kmArrivee, kmDepart);
					compagny.addTrajet(trajet);
					System.out.println(trajet.toString() + " enregistre avec succes...");
    }
    public static void etablirReservation(Scanner scan, Compagny compagny) {

        System.out.println("***************ENREGISTREMENT D UNE RESERVATION******************");
        final List<Limousine> compLimousines = compagny.getLimousines();
        final List<Chauffeur> compChauffeur = compagny.getChauffeurs();
        final List<Trajet> compTrajets = compagny.getTrajets();
        Limousine limouVoulue;
        String limouVoulueImma;
        Trajet trajetVoulu;
        int trajetVouluId;
        Chauffeur chauffVoulu;

        String chauffVouluId;
        System.out.println("Choix de la limousine... ");
        for (final Limousine limou : compLimousines) {
            System.out.println(limou.toString());
        }
        System.out.println("entrez le numero d immatriculation de la limousine voulue: ");
        limouVoulueImma = scan.next();

        System.out.println("Choix du chauffeur... ");
        for (final Chauffeur chauff : compChauffeur) {
            System.out.println(chauff.toString());
        }
        System.out.println("entrez le numero d identification du chauffeur voulu: ");
        chauffVouluId = scan.next();

        System.out.println("Choix du trajet... ");
        int trajCnt = 0;
        for (final Trajet traj : compTrajets) {
            trajCnt++;
            System.out.println(trajCnt + ". " + traj.toString());
        }
        System.out.println("entrez le numero du trajet voulu: ");
        trajetVouluId = scan.nextInt();

        // recuperer la limousine voulue parmi celles de la compagnie et ajouter a la
        // reservation
        limouVoulue = compagny.getLimousineByImma(limouVoulueImma);

        // recuperer le chauffeur voulu parmi ceux de la compagnie et ajouter a la
        // réservation
        compagny.getChauffeurById(chauffVouluId).add(limouVoulue);
        chauffVoulu = compagny.getChauffeurById(chauffVouluId);

        // recuperer le trajet voulu parmi ceux de la compagnie et ajouter à la
        // réservation
        compagny.getTrajet(trajetVouluId).setLimousine(limouVoulue);
        ;

        trajetVoulu = compagny.getTrajet(trajetVouluId);

        Reservation reservation = new Reservation(trajetVoulu, chauffVoulu);

        System.out.println(reservation.toString() + " enregistre avec succes...");

    }

    public static void trouverLimousinesConduitesParChauffeur(Scanner scan, Compagny compagny) {
        System.out.println ("***************TROUVER LA LISTE DES LIMOUSINES CONDUITES D UN CHAUFFEUR******************");
	
					final List<Chauffeur> compChauffeur= compagny.getChauffeurs();
					Chauffeur chauffVoulu;
					String chauffVouluId;
					
					for (final Chauffeur chauff : compChauffeur) {
						System.out.println (chauff.toString());
					}
					System.out.println ("entrez le numero d identification du chauffeur voulu: ");
					chauffVouluId = scan.next();
					chauffVoulu = compagny.getChauffeurById(chauffVouluId);
					
					if(chauffVoulu.getLimousinesConduites().isEmpty()) {
						System.out.println(" Ce conducteur n'a pas encore conduit une limousine");
					}else {
						System.out.println(" Les limousines conduites par ce conducteur sont: ");
	
						for (final Limousine lim : chauffVoulu.getLimousinesConduites()) {
							System.out.println (lim.toString());
						}
					}
        
    }

    public static void main(String[] args) throws Exception {
        
        compagny = new Compagny();
        // le menu pour les methodes
        int choix = 99;

        while (choix !=0) {
            final Scanner scan = new Scanner(System.in);

            choix= afficherMenu(scan, choix);
            while (choix < 0 || choix > 5) {
                System.out.println("Erreur! veuillez reessayer...");
                System.out.println("Entrez votre choix: ");
                choix = scan.nextInt();
            }

            switch (choix) {
                case 1:
                //enregistrer chauffeur
                    enregistrerChauffeur(scan, compagny);
                    choix=afficherMenu(scan, choix);
					break;

                case 2:
                //enregistrer limousine
					enregistrerLimousine(scan, compagny);
                    choix=afficherMenu(scan, choix);
					break;
                    
                case 3:
                //enregistrer trajet
					enregistrerTrajet(scan, compagny);
                    choix=afficherMenu(scan, choix);
					break;

                case 4:
                    //etablir une reservation
                    etablirReservation(scan, compagny);
                    choix=afficherMenu(scan, choix);
					break;
					
				case 5: 
					// TRouver toutes les limousines conduites par un chauffeur dans la compagnie
					trouverLimousinesConduitesParChauffeur(scan, compagny);
                    choix=afficherMenu(scan, choix);
					break;
					
				default:
					System.out.println ("Merci d'avoir utilise notre application");
					break;
				}
	
		}
		
		
		


        
    }

    
}
