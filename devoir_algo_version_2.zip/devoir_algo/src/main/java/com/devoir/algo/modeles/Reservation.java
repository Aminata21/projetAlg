package com.devoir.algo.modeles;

public class Reservation {
	
	private Trajet trajet;
	private Chauffeur chauffeur;
	
	public Reservation(Trajet trajet, Chauffeur chauffeur) {
		super();
		this.trajet = trajet;
		this.chauffeur = chauffeur;
	}

	public Trajet getTrajet() {
		return trajet;
	}

	public void setTrajet(Trajet trajet) {
		this.trajet = trajet;
	}

	public Chauffeur getChauffeur() {
		return chauffeur;
	}

	public void setChauffeur(Chauffeur chauffeur) {
		this.chauffeur = chauffeur;
	}

	@Override
	public String toString() {
		return "Reservation [trajet=" + trajet + ", chauffeur=" + chauffeur + ", \n Trajet=" + getTrajet().toString()
				+ ", \n Chauffeur=" + getChauffeur().toString()
				 +"]";
	}
	
	
	
	
	
	

}
