package com.devoir.algo.modeles;

public class Limousine {

	   private String numeroDimma;
	   private int capaciteReserv;
	   private int nombreDePassagers;
	   private String couleur;

	  public Limousine (String numeroDimma, int capaciteReserv, int nombreDePassagers, String couleur) {
			super();
		  this.numeroDimma =  numeroDimma ;
		  this.capaciteReserv = capaciteReserv;
		  this.nombreDePassagers = nombreDePassagers;
		  this.couleur = couleur;

	   
}
	  
public void setNumeroDimma (String imma) {
	  this.numeroDimma = imma;
}
public void setCapaciteReserv (int capacite) {
	  this.capaciteReserv = capacite;
}
public void setNombreDePassagers (int nbre) {
	  this.nombreDePassagers = nbre;
}
public void setCouleur (String color) {
	 this.couleur = color;
}



public String getNumeroDimma () {
	  return numeroDimma;
}

public int getCapaciteReserv () {
	  return capaciteReserv;
}

public int getNombreDePassagers () {
	  return nombreDePassagers;
}
public String getCouleur () {
	  return couleur;
}
	  
@Override
public String toString() {//Afficher les caracteristques de l instance  
    return String.format("numero d immatriculation : " +this.numeroDimma + " , capacite de reserve : " + this.capaciteReserv + " , Nombre de passagers : " + this.nombreDePassagers + " , Couleur : " + this.couleur); 
} 

	
}

