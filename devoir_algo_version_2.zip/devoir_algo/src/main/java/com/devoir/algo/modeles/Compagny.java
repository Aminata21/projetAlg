package com.devoir.algo.modeles;

import java.util.ArrayList;
import java.util.List;

import com.devoir.algo.exceptions.ElementNonTrouveException;

public class Compagny {

    private List<Chauffeur> chauffeurs;
    private List<Limousine> limousines;
    private List<Trajet> trajets;
    private List<Reservation> reservations;


    public Compagny() {
		super();
        this.chauffeurs = new ArrayList<>();
        this.limousines = new ArrayList<>();
        this.trajets = new ArrayList<>();
        this.reservations = new ArrayList<>();
    }

    public Compagny(List<Chauffeur> chauffeurs, List<Limousine> limousines) {
        this.chauffeurs = chauffeurs;
        this.limousines = limousines;
    }

    public List<Chauffeur> getChauffeurs() {
        return this.chauffeurs;
    }

    public void setChauffeurs(List<Chauffeur> chauffeurs) {
        this.chauffeurs = chauffeurs;
    }

    public List<Limousine> getLimousines() {
        return this.limousines;
    }

    public void setLimousines(List<Limousine> limousines) {
        this.limousines = limousines;
    }

    public void addChauffeur(Chauffeur chauffeur){
        this.chauffeurs.add(chauffeur);
    }
    
    
    


    public List<Trajet> getTrajets() {
		return trajets;
	}

	public void setTrajets(List<Trajet> trajets) {
		this.trajets = trajets;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}

	@Override
    public String toString() {
        return "{" +
            " chauffeurs='" + getChauffeurs() + "'" +
            ", limousines='" + getLimousines() + "'" +
            "}";
    }

	public void addLimousine(Limousine limousine) {
        this.limousines.add(limousine);
	}

	public void addTrajet(Trajet trajet) {
        this.trajets.add(trajet);
	}
	
	public void addReservation(Reservation reservation) {
        this.reservations.add(reservation);
	}
	
	public Limousine getLimousineByImma(String limImma) {
		Limousine limousine = null;
		for (Limousine limou : this.getLimousines()) {
			if(limou.getNumeroDimma().equals(limImma)) {
				limousine = limou;
			}
		}

		try {
			if (limousine.equals(null)) {
				throw new ElementNonTrouveException();
			}
		} catch (ElementNonTrouveException e) {
			System.out.println(e.getMessage());
		}
		
		return limousine;
	}
	
	public Chauffeur getChauffeurById(String chauffId) {
		Chauffeur chauffeur = null;
		for (Chauffeur chauff : this.getChauffeurs()) {
			if(chauff.getNumeroDidentification().equals(chauffId)) {
				chauffeur = chauff;
			}
		}

		try {
			if (chauffeur.equals(null)) {
				throw new ElementNonTrouveException();
			}
		} catch (ElementNonTrouveException e) {
			System.out.println(e.getMessage());
		}
		
		
		return chauffeur;
	}
	
	public Trajet getTrajet(int trajIndex) {
		Trajet trajet = null;
		int index = trajIndex-1;
		if ( index > this.getTrajets().size()) {
			return null;
		}else {
			trajet = this.getTrajets().get(index);
		}

		try {
			if (trajet.equals(null)) {
				throw new ElementNonTrouveException();
			}
		} catch (ElementNonTrouveException e) {
			System.out.println(e.getMessage());
		}
		
		return trajet;
	}


    
}