package com.devoir.algo.modeles;

public class Trajet {

    private String villeDepart;
    private String villeArrivee;
    private float kmArrivee;
    private float kmDepart;
    private Limousine limousine;
    
    public Trajet(String villeDepart, String villeArrivee, float kmArrivee, float kmDepart) {
		super();

        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.kmArrivee = kmArrivee;
        this.kmDepart = kmDepart;
    }
        

    public Trajet(String villeDepart, String villeArrivee, float kmArrivee, float kmDepart, Limousine limousine) {

        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.kmArrivee = kmArrivee;
        this.kmDepart = kmDepart;
        this.limousine = limousine;
    }

    public void setVilleDepart(String villed) {
        this.villeDepart = villed;
    }

    public void setVilleArrivee(String villea) {
        this.villeArrivee = villea;
    }

    public void setKmArrivee(float kma) {
        this.kmArrivee = kma;
    }

    public void setKmDepart(float kmd) {
        this.kmDepart = kmd;
    }

    public void setLimousine(Limousine limousine) {
        this.limousine = limousine;

    }

    public String getVilleDepart() {
        return villeDepart;
    }

    public String getVilleArrivee() {
        return villeArrivee;
    }

    public float getKmArrivee() {
        return kmArrivee;
    }

    public float getKmDepart() {
        return kmDepart;
    }

    public Limousine getLimousine() {
        return limousine;

    }


    @Override
    public String toString() {
        return "{" +
            " villeDepart='" + getVilleDepart() + "'" +
            ", villeArrivee='" + getVilleArrivee() + "'" +
            ", kmArrivee='" + getKmArrivee() + "'" +
            ", kmDepart='" + getKmDepart() + "'" +
            ", limousine='" + getLimousine() + "'" +
            "}";
    }


}
